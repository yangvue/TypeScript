import React from 'react';
import { GameComp } from './components/GameComp';

export class App extends React.Component {

    render() {
        return (
            <div>
                <GameComp />
            </div>
        )
    }
}