import { Game } from "./core/Game";
import { GamePageViewer } from "./core/viewer/GamePageViewer";
new Game(new GamePageViewer());
