export default {
    SquareSize: {
        width: 30,
        height: 30
    }
}