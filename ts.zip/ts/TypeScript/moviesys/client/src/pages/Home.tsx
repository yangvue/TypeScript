import React from "react"

export default class extends React.Component {

    render() {
        return (
            <h1>
                欢迎使用电影管理系统
            </h1>
        );
    }
}