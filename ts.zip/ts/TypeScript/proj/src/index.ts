import _ from "lodash"

const newArr = _.chunk([3, 4, 6, 7, 2], 2);

