class User {
      // 、readonly id: number//不能改变
      name: string
      age: number
      sex:"男" | "女"="男"
      pid?: string //可选？
      constructor(name: string,age: number){
        this.name = name;
        this.age = age;
      }
      private maxCount:number =3;
      private count:number =0;
      print(title: string){
          if(this.count<this.maxCount){
              console.log("出版"+title);
              this.count++
          }else{
            console.log("每天只可发布三次");
          }
      }
}
const u = new User("类别",20);
u.print("老鼠")
u.print("大米")
u.print("苏克")
u.print("贝塔")
u.print("哈哈哈")


