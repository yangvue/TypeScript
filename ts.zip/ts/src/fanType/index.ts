// type callback<T> = (n:T,i:number) => boolean;
// 接口使用泛型
interface callback<T> {
  (n:T,i:number) :boolean
}
// 泛型
function filter<T>(arr: T[],callback:callback<T>): T[]{
    let newArr:T[] =[];
    arr.forEach((n,i)=>{
      if(callback(n,i)){
        newArr.push(n)
      }
    })
    return newArr;
    
}
var arr=[1,3,4,6,8];
console.log(filter(arr,n=>n%2==0))