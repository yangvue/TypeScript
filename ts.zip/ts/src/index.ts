// function sums(a: number,b: number): number{
//   return a+b;
// }
// let num=sums(2,3);
// console.log(num);
// let name: string|undefined =undefined
// /**
//  * 得到a,b拼接
//  * @param a 
//  * @param b 
//  */
// function combine(a:string,b:string): string;
// function combine(a:number,b:number): number;//函数重载
// function combine(a: string|number,b: string|number): string|number{
//   if(typeof a == "number" && typeof b == "number"){
//     return a * b
//   }else if (typeof a == "string" && typeof b == "string") {
//     return a + b
//   }
//   throw new Error("a,b类型不相同");
  
// }
// const result = combine('2','3')
// console.log(result);
// // 可选参数
// function chose(a: number,b: number,c?: number){}
// chose(1,1)
// 默认参数
// function chose(a: number,b: number,c: number=0){
//   return a+b+c;
// }
// chose(1,1)
// chose(1,1,3)
// 起别名-------------------------
type sex='男'|'女'
type user={
  name:string
  age:number
  sex:sex
 
}
let u: user={name:"1",age:18,sex:"男"}

function people(): user[]{
  return []
}
// people("男")