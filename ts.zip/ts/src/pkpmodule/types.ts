import { color, mark } from './enum';

// export type Deck = (NormalCard | Joker)[]  这是一种方式
// export type Deck = Card[]  //这是第二种方式
// 别名
// type color = "♥"|"♣"|"♠"|"◇"
// export type NormalCard = {
//     color: color
//     mark: mark

// }
export interface Card{
      getString():string    
}
// 接口改造
export interface NormalCard extends Card{
  color: color
  mark: mark

}
// 增加大小王
export interface Joker extends Card{
  type:"big" | "small"

}