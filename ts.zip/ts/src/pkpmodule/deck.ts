import { Card, Joker } from './types'
import { mark, color } from './enum'

export class Deck {
  cards: Card[]=[] //扑克牌
  constructor() {
    this.init()
  }
  private init() {
    const marks = Object.values(mark)
    const colors = Object.values(color)
    for (const ma of marks) {
      for (const co of colors) {
        this.cards.push({
          color: co,
          mark: ma,
          getString() {
            return this.color + this.mark
          }
        } as Card)
        // 或者类型断言 as Card
        // arr.push(cards)
      }
    }
    //  存入大小王
    let joker: Joker = {
      type: 'small',
      getString() {
        return '小王'
      }
    }
    this.cards.push(joker)
    joker = {
      type: 'big',
      getString() {
        return '大王'
      }
    }
    this.cards.push(joker)
    console.log(this.cards)
  }
  // 打印
  print() {
    let result = '\n'
    this.cards.forEach((res, index) => {
      let str = res.getString()

      result += str + '\t'

      if ((index + 1) % 6 == 0) {
        result += '\n'
      }
    })
    console.log(result)
  }
  /**
   * 洗牌
   */
  shuffle(){
    for (let index = 0; index < this.cards.length; index++) {
      const MathIndex = this.getRandom(0,this.cards.length);
      const temp = this.cards[index];
      this.cards[index]= this.cards[MathIndex];
      this.cards[MathIndex]=temp;

      
    }
  }
  // 随机数获取
  private getRandom(min: number,max:number){
    const dec = max-min;
    return Math.floor(Math.random()*dec)
  }
}
