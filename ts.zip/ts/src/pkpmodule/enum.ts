export enum color{
  heart="♥",
  mei="♣",
  club="♠",
  square="◇"

}
// 使用枚举进行改造
export enum mark{
  A="A",
  two="2",
  thre="3",
  four="4",
  five="5",
  three="6",
  seven="7",
  eight="8",
  nine="9",
  ten="10",
  eleven="J",
  twelve="Q",
  king="K",
  

}