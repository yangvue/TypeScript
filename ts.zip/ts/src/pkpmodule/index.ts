import { Deck } from './deck';

const deck = new Deck();
deck.shuffle();
deck.print()