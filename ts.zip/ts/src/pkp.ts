// 创建一副扑克牌并打印出
type Deck = NormalCard[] 
enum color{
  heart="♥",
  mei="♣",
  club="♠",
  square="◇"

}
// 使用枚举进行改造
enum mark{
  A="A",
  two="2",
  thre="3",
  four="4",
  five="5",
  three="6",
  seven="7",
  eight="8",
  nine="9",
  ten="10",
  eleven="J",
  twelve="Q",
  king="K",
  

}
// 别名
// type color = "♥"|"♣"|"♠"|"◇"
type NormalCard = {
    color: color
    mark: mark

}
// 创建扑克牌
function createDeck(): Deck {
        let arr:Deck =[];
        const marks = Object.values(mark);
        const colors = Object.values(color);
       for (const mark of marks) {
         for (const color  of colors) {
          arr.push({
            color:color,
            mark:mark
          })
         }
       }
       console.log(arr);
        // for (let i = 1; i <=13; i++) {
        //   arr.push({color:"♥",mark:i})
        //   arr.push({color:"♣",mark:i})
        //   arr.push({color:"♠",mark:i})
        //   arr.push({color:"◇",mark:i})
          
        // }
        return arr;
}
// 打印扑克牌
function print(deck: Deck){
  let result="\n" ;
  deck.forEach((res,index)=>{
    let str = res.color+res.mark;
    
    result+=str+"\t"
  
    if((index+1)%6==0){
      result+="\n"
    }
    
  })
  console.log(result);
}
const sj =createDeck();
print(sj)