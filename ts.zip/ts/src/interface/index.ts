import { SIGWINCH } from 'constants';

// interface User{
//   name: string,
//   age: number,
//   sayHello:()=>void
//   eat():void //函数俩种写法
// } 约束对象
// 看起来接口和类型别名没区别 最大区别在类
// type User={
//   name: string,
//   age: number,
//   sayHello:()=>void
//   eat():void //函数俩种写法
// }
// let u:User={
//       name:"sd",
//       age:12,
//       sayHello(){
//         console.log("Hello");
//       },
//       eat(){
//         console.log("eat");
//       },
// }
//  写一个方法----------------------
// type Condition = (n:number) => boolean // 用类型别名
//  type Condition= {(n:number):boolean}
// 用接口写约束函数 {大括号里没有任何成员名称如name}
// interface Condition {
//   (n:number):boolean
// }
// function sum(numbers: number[],callbacks: Condition){
//     let s = 0;
//     numbers.forEach(n=>{
//       if(callbacks(n)){
//         s+=n;
//       }
//     })
//     return s;
// }
// const result = sum([1,2,3],n=>n%2!==0)
// console.log(result);
// ------------------接口可以继承
// 使用类型别名也可以实现交叉类型
// type A = {
//   name: string
// }
// type B = {
//   age: number
// }
// type C = {
//   sex: string
// }& A & B
// interface A{
//   name: string
// }
// interface B{
//   age: number
// }
// interface C extends A,B{
//   sex: string
// }
// let people: C = {
//    age:12,
//    name:"小明",
//    sex:"男"
// }

// 类型兼容性
  interface Duck{
    sound: "嘎",
    swin():void
  }
  let person = {
    name:"类型兼容性",
    age:16,
    sound: "嘎" as "嘎",
    swin(){
      console.log(this.name + "发出了"+this.sound+"的声音")
    }
  }
  let Duck: Duck = person