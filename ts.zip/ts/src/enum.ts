enum Gender{
  male="男",
  female="女"
}
let sex: Gender
sex =Gender.male
sex =Gender.female
console.log(sex);