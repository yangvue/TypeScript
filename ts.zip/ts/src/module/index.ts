// import { name, sum } from './mymodule';
// import fs from "fs"; //module.exports={}
// // console.log(name);
// fs.readFileSync("./");

// console.log(sum(1,9));
// Commonjs导入
import mymodule = require("./mymodule")
mymodule.name
console.log(mymodule.sum(1,2))