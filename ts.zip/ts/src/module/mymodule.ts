// 推荐使用导出这种方式
// export var name="TS"
// export function sum(a: number,b: number){
//   return a+b;
// }

// 默认导出没有智能提示不推荐使用
// export default{
//    name:"ts",
//    sum(a,b){
//     return a+b;
//   }
// }
// 如果一定要用commonJS--------------
export = {
  name:"开发",
  sum(a: number,b:number ){
    return a+b;
  }
}
